# TeacherCo Assessment Slot Handoff

## Goal
Let teachers classify a score activity by term, grading component, and exact workbook slot when they create it. This should make export predictable and prevent scores being placed in the wrong class-record column.

## User Request
Examples include `Term 1 - Performance Task 1`, `Term 1 - Performance Task 2`, and `Term 1 - Summative Test 1`. The activity title should remain teacher-editable, but structured metadata—not title text—should drive grading and export.

## Current Findings
- The Check assessment form is `src/features/exams/components/new-assessment-form.tsx`. It currently asks for class, title, date, question format, item count, and points. It does not ask for term/component/slot.
- Check assessments are created by `src/features/exams/actions.ts`. The create action saves `class_id`, title, kind, status, date, total points, and answer-key metadata, but does not save term/component.
- The Scores page creates a second activity type (manual typed scores, such as oral recitation). Its form/action are `src/features/scores/new-activity-form.tsx` and `src/features/scores/actions.ts`; they also do not ask for or save term/component/slot. Both creation paths need consistent tagging.
- `assessments.term` and `assessments.component` already exist from migration `0012_grading_reference.sql`. Allowed components are `written_work`, `performance_task`, and `assessment`. There is no exact slot column or duplicate-slot constraint yet.
- Migration `0001_teacherco_foundation.sql` defines the base assessments table. Migration `0005_assessment_checking.sql` adds answer-sheet checking support. Migration `0008_assessment_source.sql` adds `source` values `checked`, `imported`, and `manual`.
- `src/lib/excel/export-plan.ts` first matches by title. For unmatched activities it offers/suggests empty workbook columns filtered by term and component, and does not overwrite prepared columns with a different HPS. It currently has no slot metadata, so same-component activities are assigned to the first compatible free slot or manually mapped.
- `src/features/export/actions.ts` already reads assessment term/component and passes them to export planning.
- `src/lib/excel/grades.ts` recognizes WW/Oral Work, Performance Task, ST1, ST2, and TE columns and can infer a term/component from a term-sheet title. `src/features/learners/grade-actions.ts` currently imports score columns but does not persist term/component/slot on each imported assessment.
- DepEd grade calculation is in `src/lib/grading/deped.ts`; current subject defaults are in `src/lib/grading/presets.ts`. Activity slot metadata must not replace per-item points or class-level component weights.
- The existing `src/types/domain.ts` currently has no Assessment interface.
- The user's current versions of `src/app/(dashboard)/classes/[classId]/term-grades/page.tsx` and `src/features/grading/term-grades-table.tsx` may have local edits. Read them before changing; preserve those edits.

## Recommended Data Model
- Keep `term` and `component` as separate fields.
- Add an exact `slot`/`slot_code` field on assessments, with a check constraint for canonical slots: `WW1`-`WW5`, `PT1`-`PT3`, `ST1`, `ST2`, `TE`.
- Use a partial unique index over `(class_id, term, slot_code)` where all are non-null, so simultaneous tabs cannot create duplicate assignments. Confirm/backfill any conflicts before enforcing it.
- For ST1/ST2/TE, `component` is `assessment`; slot code distinguishes which assessment it is.
- Permit an unassigned/out-of-term activity when appropriate, but make it explicit and do not silently include it in term grades or auto-export it.
- For classes without an imported record, show standard slot options. When a workbook is imported, offer only detected slots and preserve its HPS.
- Imported scores should be tagged automatically from their detected sheet/column. Existing untagged assessments should stay visibly `Not tagged` and be taggable by the teacher; do not guess from an arbitrary title.

## Export Behavior
- Prefer exact `(term, slot_code)` matching.
- Use component as a validation/fallback filter, not the sole identity for PT1 versus PT2 or ST1 versus ST2.
- If the exact slot is occupied by another activity, show a conflict and require an explicit safe choice; never overwrite an occupied column.
- Keep title-based matching only as a legacy fallback, and keep the current HPS mismatch/no-overwrite safety behavior.

## Acceptance Checks
1. Both Check and Scores creation screens offer term, component, and valid slot choices.
2. Saved rows contain normalized `term`, `component`, and `slot_code` metadata.
3. Duplicate class/term/slot assignments are rejected in both the action and database constraint.
4. Export sends a Term 1 PT2 activity to PT2, not PT1, and preserves manual mapping when no exact slot exists.
5. Existing workbook HPS and learner rows are not overwritten; free slots only receive their HPS after explicit confirmation/download.
6. Workbook imports auto-tag parsed terms/components/slots and retain unscored HPS columns.
7. Existing untagged activities remain visible and can be classified later.
8. Regression tests cover both creation paths, conflict handling, import tagging, same-component multiple slots, and safe export.

## Relevant Files
- `src/features/exams/components/new-assessment-form.tsx`
- `src/features/exams/components/edit-key-form.tsx`
- `src/features/exams/actions.ts`
- `src/app/(dashboard)/check/new/page.tsx`
- `src/features/exams/queries.ts`
- `src/features/scores/new-activity-form.tsx`
- `src/features/scores/actions.ts`
- `src/app/(dashboard)/classes/[classId]/scores/page.tsx`
- `src/lib/excel/export-plan.ts`
- `src/features/export/actions.ts`
- `src/features/export/export-record.tsx`
- `src/app/(dashboard)/classes/[classId]/export/page.tsx`
- `src/lib/excel/grades.ts`
- `src/lib/excel/parser.ts`
- `src/features/learners/grade-actions.ts`
- `src/lib/grading/deped.ts`
- `src/lib/grading/presets.ts`
- `src/features/grading/queries.ts`
- `src/features/grading/term-grades-table.tsx`
- `src/types/domain.ts`
- `supabase/migrations/0001_teacherco_foundation.sql`
- `supabase/migrations/0005_assessment_checking.sql`
- `supabase/migrations/0008_assessment_source.sql`
- `supabase/migrations/0012_grading_reference.sql`
- `tests/export-free-slots.test.ts`
- `tests/grades.test.ts`
- `tests/deped-grading.test.ts`
- `tests/grading-workbook-parser.test.ts`

Do not include learner workbooks or real student records in the implementation bundle.
